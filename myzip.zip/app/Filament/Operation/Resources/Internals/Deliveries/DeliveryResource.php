<?php

namespace App\Filament\Operation\Resources\Internals\Deliveries;

use App\Filament\Operation\Resources\Internals\Deliveries\Pages\CreateDelivery;
use App\Filament\Operation\Resources\Internals\Deliveries\Pages\EditDelivery;
use App\Filament\Operation\Resources\Internals\Deliveries\Pages\ListDeliveries;
use App\Filament\Operation\Resources\Internals\Deliveries\Pages\ViewDelivery;
use App\Filament\Operation\Resources\Internals\Deliveries\Schemas\DeliveryForm;
use App\Filament\Operation\Resources\Internals\Deliveries\Tables\DeliveriesTable;
use App\Models\Delivery;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class DeliveryResource extends Resource
{
    protected static ?string $model = Delivery::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedMap;

    public static function form(Schema $schema): Schema
    {
        return DeliveryForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return DeliveriesTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListDeliveries::route('/'),
            'create' => CreateDelivery::route('/create'),
            'view' => ViewDelivery::route('/{record}'),
            'edit' => EditDelivery::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::where('status', 'pending')->count();

        return $count > 0 ? (string) $count : null;
    }

    public static function getEloquentQuery(): Builder
{
    return parent::getEloquentQuery()->with('deliveryNoteDocument');
}
}
